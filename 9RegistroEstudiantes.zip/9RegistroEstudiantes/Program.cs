﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace _9RegistroEstudiantes
{
    /*Crea un programa que permita registrar información de estudiantes (nombre, edad,
    promedio) en un archivo binario. Implementa funciones para agregar, buscar y listar
    estudiantes según se indica:
    - Cantidad de estudiantes menores de edad
    - Cantidad de estudiantes mayores de edad
    - Promedio mayor*/

    //Definimos la estructura Estudiante
    [Serializable] 
    public struct Estudiante
    {
        public string Nombre;
        public int Edad;
        public double Promedio;

        public Estudiante(string nombre, int edad, double promedio)
        {
            Nombre = nombre;
            Edad = edad;
            Promedio = promedio;
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            string archivo = "estudiantes.bin";

            while (true)
            {
                Console.WriteLine("Seleccione una opción:");
                Console.WriteLine("1. Agregar estudiante");
                Console.WriteLine("2. Buscar estudiante por nombre");
                Console.WriteLine("3. Mostrar cantidad de menores de edad");
                Console.WriteLine("4. Mostrar cantidad de mayores de edad");
                Console.WriteLine("5. Mostrar estudiante con mayor promedio");
                Console.WriteLine("6. Salir");

                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        AgregarEstudiante(archivo);
                        break;
                    case "2":
                        BuscarEstudiantePorNombre(archivo);
                        break;
                    case "3":
                        MostrarMenoresDeEdad(archivo);
                        break;
                    case "4":
                        MostrarMayoresDeEdad(archivo);
                        break;
                    case "5":
                        MostrarEstudianteConMayorPromedio(archivo);
                        break;
                    case "6":
                        return;
                    default:
                        Console.WriteLine("Opción no válida. Intente de nuevo.");
                        break;
                }
            }
        }

        static void AgregarEstudiante(string archivo)
        {
            Console.Write("Ingrese el nombre del estudiante: ");
            string nombre = Console.ReadLine();
            Console.Write("Ingrese la edad del estudiante: ");
            int edad = int.Parse(Console.ReadLine());
            Console.Write("Ingrese el promedio del estudiante: ");
            double promedio = double.Parse(Console.ReadLine());

            Estudiante estudiante = new Estudiante(nombre, edad, promedio);

            // Guardar en archivo binario
            List<Estudiante> estudiantes = new List<Estudiante>();

            // Leer los estudiantes existentes
            if (File.Exists(archivo))
            {
                using (FileStream stream = new FileStream(archivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    estudiantes = (List<Estudiante>)formatter.Deserialize(stream);
                }
            }

            // Agregar nuevo estudiante
            estudiantes.Add(estudiante);

            // Guardar de nuevo todos los estudiantes
            using (FileStream stream = new FileStream(archivo, FileMode.Create, FileAccess.Write))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, estudiantes);
            }

            Console.WriteLine("Estudiante agregado correctamente.");
        }

        static void BuscarEstudiantePorNombre(string archivo)
        {
            Console.Write("Ingrese el nombre del estudiante a buscar: ");
            string nombreBuscar = Console.ReadLine();

            if (File.Exists(archivo))
            {
                using (FileStream stream = new FileStream(archivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    List<Estudiante> estudiantes = (List<Estudiante>)formatter.Deserialize(stream);

                    bool encontrado = false;
                    foreach (var estudiante in estudiantes)
                    {
                        if (estudiante.Nombre.Equals(nombreBuscar, StringComparison.OrdinalIgnoreCase))
                        {
                            Console.WriteLine($"Nombre: {estudiante.Nombre}, Edad: {estudiante.Edad}, Promedio: {estudiante.Promedio}");
                            encontrado = true;
                        }
                    }

                    if (!encontrado)
                    {
                        Console.WriteLine("Estudiante no encontrado.");
                    }
                }
            }
            else
            {
                Console.WriteLine("No hay estudiantes registrados.");
            }
        }

        static void MostrarMenoresDeEdad(string archivo)
        {
            if (File.Exists(archivo))
            {
                using (FileStream stream = new FileStream(archivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    List<Estudiante> estudiantes = (List<Estudiante>)formatter.Deserialize(stream);

                    int menoresDeEdad = 0;
                    foreach (var estudiante in estudiantes)
                    {
                        if (estudiante.Edad < 18)
                        {
                            menoresDeEdad++;
                        }
                    }

                    Console.WriteLine($"Cantidad de estudiantes menores de edad: {menoresDeEdad}");
                }
            }
            else
            {
                Console.WriteLine("No hay estudiantes registrados.");
            }
        }

        static void MostrarMayoresDeEdad(string archivo)
        {
            if (File.Exists(archivo))
            {
                using (FileStream stream = new FileStream(archivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    List<Estudiante> estudiantes = (List<Estudiante>)formatter.Deserialize(stream);

                    int mayoresDeEdad = 0;
                    foreach (var estudiante in estudiantes)
                    {
                        if (estudiante.Edad >= 18)
                        {
                            mayoresDeEdad++;
                        }
                    }

                    Console.WriteLine($"Cantidad de estudiantes mayores de edad: {mayoresDeEdad}");
                }
            }
            else
            {
                Console.WriteLine("No hay estudiantes registrados.");
            }
        }

        static void MostrarEstudianteConMayorPromedio(string archivo)
        {
            if (File.Exists(archivo))
            {
                using (FileStream stream = new FileStream(archivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    List<Estudiante> estudiantes = (List<Estudiante>)formatter.Deserialize(stream);

                    if (estudiantes.Count == 0)
                    {
                        Console.WriteLine("No hay estudiantes registrados.");
                        return;
                    }

                    Estudiante estudianteConMayorPromedio = estudiantes[0];

                    foreach (var estudiante in estudiantes)
                    {
                        if (estudiante.Promedio > estudianteConMayorPromedio.Promedio)
                        {
                            estudianteConMayorPromedio = estudiante;
                        }
                    }

                    Console.WriteLine($"Estudiante con mayor promedio: {estudianteConMayorPromedio.Nombre}, Promedio: {estudianteConMayorPromedio.Promedio}");
                }
            }
            else
            {
                Console.WriteLine("No hay estudiantes registrados.");
            }
        }
    }
}
