﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace _4LibroBin
{
    /*Define una estructura Libro con propiedades como Título, Autor y Año. Escribe un
    programa que almacene varios registros de libros en un archivo binario y permita al usuario
    buscar por título.
    */

    // Definimos la estructura Libro
    [Serializable]
    public struct Libro
    {
        public string Titulo;
        public string Autor;
        public int Year;

        public Libro(string titulo, string autor, int year)
        {
            Titulo = titulo;
            Autor = autor;
            Year = year;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            string archivo = "libros.bin";

            // Menú
            while (true)
            {
                Console.WriteLine("Seleccione una opción:");
                Console.WriteLine("1. Agregar libro");
                Console.WriteLine("2. Buscar libro por título");
                Console.WriteLine("3. Salir");

                string opcion = Console.ReadLine();

                switch (opcion)
                {
                    case "1":
                        AgregarLibro(archivo);
                        break;
                    case "2":
                        BuscarLibroPorTitulo(archivo);
                        break;
                    case "3":
                        return;
                    default:
                        Console.WriteLine("Opción no válida. Intente de nuevo.");
                        break;
                }
            }
        }

        static void AgregarLibro(string archivo)
        {
            Console.Write("Ingrese el título del libro: ");
            string titulo = Console.ReadLine();
            Console.Write("Ingrese el autor del libro: ");
            string autor = Console.ReadLine();
            Console.Write("Ingrese el año de publicación: ");
            int year = int.Parse(Console.ReadLine());

            Libro libro = new Libro(titulo, autor, year);

            // Guardar en archivo binario
            List<Libro> libros = new List<Libro>();

            // Leer los libros existentes
            if (File.Exists(archivo))
            {
                using (FileStream stream = new FileStream(archivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    libros = (List<Libro>)formatter.Deserialize(stream);
                }
            }

            // Agregar nuevo libro
            libros.Add(libro);

            // Guardar de nuevo todos los libros
            using (FileStream stream = new FileStream(archivo, FileMode.Create, FileAccess.Write))
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, libros);
            }

            Console.WriteLine("Libro agregado correctamente.");
        }

        static void BuscarLibroPorTitulo(string archivo)
        {
            Console.Write("Ingrese el título del libro a buscar: ");
            string tituloBuscar = Console.ReadLine();

            if (File.Exists(archivo))
            {
                using (FileStream stream = new FileStream(archivo, FileMode.Open, FileAccess.Read))
                {
                    BinaryFormatter formatter = new BinaryFormatter();
                    List<Libro> libros = (List<Libro>)formatter.Deserialize(stream);

                    bool encontrado = false;
                    foreach (var libro in libros)
                    {
                        if (libro.Titulo.Equals(tituloBuscar, StringComparison.OrdinalIgnoreCase))
                        {
                            Console.WriteLine($"Título: {libro.Titulo}, Autor: {libro.Autor}, Año: {libro.Year}");
                            encontrado = true;
                        }
                    }

                    if (!encontrado)
                    {
                        Console.WriteLine("Libro no encontrado.");
                    }
                }
            }
            else
            {
                Console.WriteLine("No hay libros en el archivo.");
            }
        }
    }
}
